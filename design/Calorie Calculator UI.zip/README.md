
  # Calorie Calculator UI

  This is a code bundle for Calorie Calculator UI. The original project is available at https://www.figma.com/design/h7V7uwiZ9bKUDymjooaf2T/Calorie-Calculator-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  